# stock-lab
 [![](https://img.shields.io/badge/python-3.6+-green.svg)](https://www.python.org/download/releases/3.6.0/)
